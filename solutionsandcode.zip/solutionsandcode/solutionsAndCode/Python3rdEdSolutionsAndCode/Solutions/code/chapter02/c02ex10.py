#c02ex10.py
#    Kilometers to miles conversion

def main():
    print("This program converts kilometers to miles.")
    print()
    
    kms = eval(input("Enter the distance in kilometers: "))
    miles = kms * 0.62
    print("The distance is", miles, "miles.")

main()
